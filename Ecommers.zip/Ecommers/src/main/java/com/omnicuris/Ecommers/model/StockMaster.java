package com.omnicuris.Ecommers.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class StockMaster {
	private Long sno;
	private String itemCode;
	private int quantity;
	private  Date updatedDate;
	private String updatedId;
	@Id
	@GeneratedValue
	public Long getSno() {
		return sno;
	}
	public void setSno(Long sno) {
		this.sno = sno;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getUpdatedId() {
		return updatedId;
	}
	public void setUpdatedId(String updatedId) {
		this.updatedId = updatedId;
	}
	@Override
	public String toString() {
		return "StockMaster [sno=" + sno + ", itemCode=" + itemCode + ", quantity=" + quantity + ", updatedDate="
				+ updatedDate + ", updatedId=" + updatedId + "]";
	}
	
}
