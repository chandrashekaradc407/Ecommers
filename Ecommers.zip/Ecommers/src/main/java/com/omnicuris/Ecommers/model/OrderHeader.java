package com.omnicuris.Ecommers.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Transient;
@Entity
public class OrderHeader {

	private Long sno;
	private String orderId;
	private int numberOfItems;
	private Date createdDate;
	private Date upatedDate;
	private String userId;
	private String remarks;
	private boolean status;
	private int OrderQuantity;
//	@Transient
//	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "Order")
//	private List<OrderDetal> orderDetail;
	
	@Id
	@GeneratedValue
	public Long getSno() {
		return sno;
	}

	public void setSno(Long sno) {
		this.sno = sno;
	}

	

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpatedDate() {
		return upatedDate;
	}

	public void setUpatedDate(Date upatedDate) {
		this.upatedDate = upatedDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public int getOrderQuantity() {
		return OrderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		OrderQuantity = orderQuantity;
	}


	@Override
	public String toString() {
		return "OrderHeader [sno=" + sno + ", orderId=" + orderId + ", numberOfItems=" + numberOfItems
				+ ", createdDate=" + createdDate + ", upatedDate=" + upatedDate + ", userId=" + userId + ", remarks="
				+ remarks + ", status=" + status + ", OrderQuantity=" + OrderQuantity + "]";
	}

	
	
}
