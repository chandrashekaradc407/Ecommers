package com.omnicuris.Ecommers.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.omnicuris.Ecommers.model.ItemMaster;
@Repository
public interface ItemRepository extends JpaRepository<ItemMaster, Long>{
	
	@Query("select i from ItemMaster i where itemcode=?1")
	ItemMaster findByItemCode(String itemCode);
	
}
