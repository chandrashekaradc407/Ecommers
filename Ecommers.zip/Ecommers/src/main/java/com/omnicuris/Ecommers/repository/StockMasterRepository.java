package com.omnicuris.Ecommers.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.omnicuris.Ecommers.model.StockMaster;

public interface StockMasterRepository  extends JpaRepository<StockMaster, Long>{

	@Query("select s from StockMaster s where  s.itemCode=?1")
	List<StockMaster> getCurrentStock(String itemCode);

}
