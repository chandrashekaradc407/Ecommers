package com.omnicuris.Ecommers.repository;

import org.apache.catalina.mbeans.UserMBean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.omnicuris.Ecommers.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long>{

	User findByEmail(String email);

	User findByMobileNo(String mobileNo);

	User findByUserId(String userId);
	
}