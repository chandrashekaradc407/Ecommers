package com.omnicuris.Ecommers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommersApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommersApplication.class, args);
	}

}
