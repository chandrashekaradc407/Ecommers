package com.omnicuris.Ecommers.util;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONResponseUtil {

	public static enum STATUS {
		Success, Failure
	}

	public static final String REMARKS = "remarks";

	public static final String STATUS = "status";

	public static final String MESSAGE = "message";
	public static Map<String, String> errorOrSuccessResponse(String remarks,STATUS status, String message) throws Exception {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put(REMARKS, remarks);
		map.put(STATUS, status.name());
		map.put(MESSAGE, message);
		return map;
	}
	public static String response(Map<String, Object> mapObj) throws Exception {
		return new ObjectMapper().writeValueAsString(mapObj);
	}
	
	

}
