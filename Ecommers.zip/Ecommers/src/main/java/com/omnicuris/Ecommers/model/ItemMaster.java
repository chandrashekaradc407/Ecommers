package com.omnicuris.Ecommers.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
public class ItemMaster {

	private Long sno;
	private String itemcode;
	private String itemName;
	private String url;
	private Date createdDate;
	private Date updatedDate;
	private String createdId;
	private String UpdatedId;
	
	private boolean status;
	
	@Id
	@GeneratedValue
	public Long getSno() {
		return sno;
	}
	public void setSno(Long sno) {
		this.sno = sno;
	}
	@NotNull
	@NotEmpty
	@Column(unique=true)
	public String getItemcode() {
		return itemcode;
	}

	public void setItemcode(String itemcode) {
		this.itemcode = itemcode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getCreatedId() {
		return createdId;
	}

	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}

	public String getUpdatedId() {
		return UpdatedId;
	}

	public void setUpdatedId(String updatedId) {
		UpdatedId = updatedId;
	}

	@Override
	public String toString() {
		return "ItemMaster [sno=" + sno + ", itemcode=" + itemcode + ", itemName=" + itemName + ", url=" + url
				+ ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + ", createdId=" + createdId
				+ ", UpdatedId=" + UpdatedId + ", status=" + status + "]";
	}
	
}
