package com.omnicuris.Ecommers.controllers;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.omnicuris.Ecommers.model.ItemMaster;
import com.omnicuris.Ecommers.model.OrderDetal;
import com.omnicuris.Ecommers.model.OrderHeader;
import com.omnicuris.Ecommers.model.StockMaster;
import com.omnicuris.Ecommers.model.User;
import com.omnicuris.Ecommers.repository.ItemRepository;
import com.omnicuris.Ecommers.repository.OrderDetailRepository;
import com.omnicuris.Ecommers.repository.OrderHeaderRepository;
import com.omnicuris.Ecommers.repository.StockMasterRepository;
import com.omnicuris.Ecommers.repository.UserRepository;
import com.omnicuris.Ecommers.util.JSONResponseUtil;
import com.omnicuris.Ecommers.util.JSONResponseUtil.STATUS;

@RestController
@RequestMapping("/ecommers")
public class RestControllerClass {

	@Autowired
	private ItemRepository itemRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private OrderHeaderRepository orderHeaderRepository;
	
	@Autowired
	private OrderDetailRepository orderDetailRepository;
	
	@Autowired
	private StockMasterRepository stockMasterRepository;
	
	
	private String generateClientId(String role) {
		   boolean generatedIdNotDuplicated=true;
		   String generatedId="";
		   String prefix="";
		   if(role.equals("ROLE_OWNER")) prefix="OWN";
		   else if(role.equals("ROLE_ADMIN")) prefix="ADMIN";
		   else prefix="USR";
		   while (generatedIdNotDuplicated) {
			   int randomNumber = (int) (Math.random() * 9000) + 100000;
			   generatedId=prefix+randomNumber;
			   User user=userRepository.findByUserId(generatedId);
			   if(user==null) generatedIdNotDuplicated=false;
		   }
		return generatedId;
	}
	
	private String generateOrderId() {
		boolean generatedIdNotDuplicated=true;
		String generatedId="";
		String prefix="ORD";
		while (generatedIdNotDuplicated) {
			int randomNumber = (int) (Math.random() * 9000) + 100000;
			generatedId=prefix+randomNumber;
			OrderHeader ordHdr=orderHeaderRepository.findRegisterByOrderId(generatedId);
			if(ordHdr==null) generatedIdNotDuplicated=false;
		}
		return generatedId;
	}
	
	@PostMapping("/insertOrUpdateItem")
	public ResponseEntity<String> insertOrUpdateItem(@RequestParam("image") MultipartFile image,@RequestParam("itemCode") String itemCode,@RequestParam("itemName") String itemName,HttpServletRequest request) {
		Map<String, Object> map = new HashMap<String, Object>();
		String loginUserId="10001";  // by security or from login user
		ItemMaster itmmst = new ItemMaster();
		 ItemMaster itemMaster = itemRepository.findByItemCode(itemCode);
		 if(itemMaster != null)  itmmst.setSno(itemMaster.getSno());
			try {
				ServletContext servletContext = request.getSession().getServletContext();
				File dir = new File(servletContext.getRealPath("") + File.separator + "resources/" + "documents");
				System.out.println("Folder dir : " + dir);
				if (!dir.exists())	dir.mkdirs();
				String fileName =image.getOriginalFilename();
				if(fileName!=null && !fileName.equalsIgnoreCase("")) {
				String fname = fileName.substring(0, fileName.indexOf(".")).trim();
				String ext = fileName.substring(fileName.indexOf(".") + 1, fileName.length()).trim();
				byte[] bytes = image.getBytes();
				String imageName = fname+"." + ext;
				Path path = Paths.get(dir + File.separator + imageName);
				Files.write(path, bytes);
				String imgpath = "resources/iteams" + "/" + imageName;
				itmmst.setItemcode(itemCode);
				itmmst.setItemName(itemName);
				itmmst.setStatus(true);
				itmmst.setUrl(imgpath);
				itmmst.setCreatedDate(new Date());
				itmmst.setUpdatedDate(new Date());
				itmmst.setCreatedId(loginUserId);
				itmmst.setUpdatedId(loginUserId);
				
				itemRepository.saveAndFlush(itmmst);
				map.put("Record", itmmst);
				map.putAll(JSONResponseUtil.errorOrSuccessResponse("Success",STATUS.Success, "Inserted Successfully"));
			}
		} catch (Exception e) {
			try {
				map.putAll(JSONResponseUtil.errorOrSuccessResponse(e.getMessage(),STATUS.Failure, "Exception"));
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
			try {
				return ResponseEntity.accepted().header(HttpHeaders.CONTENT_TYPE, "application/json").body(new ObjectMapper().writeValueAsString(map));
			} catch (Exception e) {
				e.printStackTrace();
			}
		return null;
	}
	@PostMapping("/deleteItem")
	public ResponseEntity<String> deletItem(@RequestParam("itemCode") String itemCode) {
		Map<String, Object> map = new HashMap<String, Object>();
		 ItemMaster itemMaster = itemRepository.findByItemCode(itemCode);
		 if(itemMaster != null) {
			 itemMaster.setStatus(false);
			 map.put("itemRecord", itemMaster);
			 try {
				 map.putAll(JSONResponseUtil.errorOrSuccessResponse("Success",STATUS.Success, "Deleted Successfully"));
			 } catch (Exception e1) {
				 e1.printStackTrace();
			 }
		 }else {
			 try {
				 map.putAll(JSONResponseUtil.errorOrSuccessResponse("ItemNotExist",STATUS.Failure, "Empty"));
			 } catch (Exception e1) {
				 e1.printStackTrace();
			 }
		 }
		try {
			return ResponseEntity.accepted().header(HttpHeaders.CONTENT_TYPE, "application/json").body(new ObjectMapper().writeValueAsString(map));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	@PostMapping("/createUser")
	public ResponseEntity<String> addRegistratorUser(@RequestBody User userRecord) throws Exception {
		User regMst=userRepository.findByEmail(userRecord.getEmail());
    	Map<String, Object> map = new HashMap<String, Object>();
    	if(regMst==null){
    		User regMstForMobileNo=userRepository.findByMobileNo(userRecord.getMobileNo());
    		if(regMstForMobileNo==null){
    			userRecord.setCreatedDate(new Date());
    			userRecord.setUpdatedDate(new Date());
        		String userId=generateClientId(userRecord.getRole());
        		userRecord.setUpdatedId(userId);
        		userRecord.setCreatedId(userId);
        		userRecord.setUserId(userId);
        		userRecord.setStatus(true);
        		userRepository.saveAndFlush(userRecord);
                map.putAll(JSONResponseUtil.errorOrSuccessResponse("Registration",STATUS.Success, "Registration Success"));
    		}
    		else{
        		map.putAll(JSONResponseUtil.errorOrSuccessResponse("mobile",STATUS.Failure, "Mobile Number Already Exists"));
        	}
    }
    	else{
    		map.putAll(JSONResponseUtil.errorOrSuccessResponse("email",STATUS.Failure, "Email Already Exists"));
    	}
    	map.put("User", userRecord); 
    	return ResponseEntity.accepted().header(HttpHeaders.CONTENT_TYPE, "application/json")
				.body(JSONResponseUtil.response(map));
		
	}
	@GetMapping("/getAllItems")
	public ResponseEntity<String> getAllItems() throws Exception {
    	Map<String, Object> map = new HashMap<String, Object>();
    	List<ItemMaster> itemMasterList = itemRepository.findAll();
    	map.put("items", itemMasterList);
    	map.putAll(JSONResponseUtil.errorOrSuccessResponse("Success",STATUS.Success, "Fetching All Items"));
    	return ResponseEntity.accepted().header(HttpHeaders.CONTENT_TYPE, "application/json")
				.body(JSONResponseUtil.response(map));
		
	}
	
	@GetMapping("/getAllOrders")
	public ResponseEntity<String> getAllOrders(@RequestParam("userId") String userId) throws Exception {
    	Map<String, Object> map = new HashMap<String, Object>();
    	User user = userRepository.findByUserId(userId);
    	if(user != null) {
    		List<OrderHeader> orderHeader = orderHeaderRepository.getAllOrderyByUserId(userId);
    		map.putAll(JSONResponseUtil.errorOrSuccessResponse("Success",STATUS.Success, "Fetching All Orders"));
    		map.put("allOrders",orderHeader );
    	}
    	else {
    		map.putAll(JSONResponseUtil.errorOrSuccessResponse("User Not Exists",STATUS.Failure, "Fetching All Orders"));
    		
    	}
    	return ResponseEntity.accepted().header(HttpHeaders.CONTENT_TYPE, "application/json")
				.body(JSONResponseUtil.response(map));
		
	}
	
	/*@PostMapping("/Order")
	public ResponseEntity<String> addRegistratorUser(@RequestBody OrderHeader orderHeader,@RequestParam("userid") String userid) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(orderHeader != null && orderHeader.getOrderDetail() != null && orderHeader.getOrderDetail().size()>0) {
			String orderId=generateOrderId();
			orderHeader.setOrderId(orderId);
			orderHeader.setUpatedDate(new Date());
			orderHeader.setUserId(userid);
			orderHeader.setCreatedDate(new Date());
			orderHeader.getOrderDetail().parallelStream().forEach(orderdtl ->{
				orderdtl.setOrderId(orderId);
				orderdtl.setUpdatedDate(new Date());
				orderdtl.setCreatedDate(new Date());
				orderdtl.setUserid(userid);
			});
			orderHeaderRepository.saveAndFlush(orderHeader);
			map.putAll(JSONResponseUtil.errorOrSuccessResponse("Success",STATUS.Success, "Inserted Successfully"));
		}else {
			map.putAll(JSONResponseUtil.errorOrSuccessResponse("Error",STATUS.Success, "Faild"));
		}
		return ResponseEntity.accepted().header(HttpHeaders.CONTENT_TYPE, "application/json")
				.body(JSONResponseUtil.response(map));
	}
	*/
	@PostMapping("/Order")
	public ResponseEntity<String> addRegistratorUser(@RequestBody List<OrderDetal> orderDetailList,@RequestParam("userid") String userid) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(orderDetailList != null && orderDetailList.size()>0) {
			OrderHeader orderHeader = new OrderHeader();
			String orderId=generateOrderId();
			orderHeader.setOrderId(orderId);
			orderHeader.setUpatedDate(new Date());
			orderHeader.setUserId(userid);
			orderHeader.setCreatedDate(new Date());
			int quantity=0;
			int numberOfIteams=0;
			Consumer<OrderDetal> consumer = new Consumer<OrderDetal>() {
				
				@Override
				public void accept(OrderDetal orderdtl) {
					
					orderdtl.setOrderId(orderId);
					orderdtl.setUpdatedDate(new Date());
					orderdtl.setCreatedDate(new Date());
					orderdtl.setUserid(userid);
					orderdtl.setStatus(true);
					List<StockMaster> stockMaster = stockMasterRepository.getCurrentStock(orderdtl.getItemCode());
					if(stockMaster != null && !stockMaster.isEmpty()) {
						if(!(orderdtl.getQuantity()<=stockMaster.get(0).getQuantity())) orderdtl.setRemarks("Available Quantity is " + stockMaster.get(0).getQuantity() );
					}else {
						orderdtl.setRemarks("Available Quantity is " + 0 );
					}
					
				}
			};
			orderDetailList.parallelStream().forEach(consumer);
		boolean quantityAvailable=true;
			for(OrderDetal orderdtl :orderDetailList) {
				if(quantityAvailable && (orderdtl.getRemarks() != null && orderdtl.getRemarks().contains("Available"))) quantityAvailable=false;
				numberOfIteams++;
				quantity += orderdtl.getQuantity();
			}
			orderHeader.setOrderQuantity(quantity);
			orderHeader.setNumberOfItems(numberOfIteams);
			orderHeader.setStatus(true);
			map.put("OrderHeader",orderHeader);
			map.put("OrderDetail",orderDetailList);
			if(quantityAvailable) {
				orderHeaderRepository.saveAndFlush(orderHeader);
				orderDetailRepository.saveAll(orderDetailList);
				map.putAll(JSONResponseUtil.errorOrSuccessResponse("Success",STATUS.Success, "Inserted Successfully"));
			}else {
				map.putAll(JSONResponseUtil.errorOrSuccessResponse("Quantity Not Available for some products  ",STATUS.Failure, "Check Remarks Field"));
			}
		}else {
			map.putAll(JSONResponseUtil.errorOrSuccessResponse("Error",STATUS.Success, "Faild"));
		}
		return ResponseEntity.accepted().header(HttpHeaders.CONTENT_TYPE, "application/json")
				.body(JSONResponseUtil.response(map));
	}
	
	// for One by one item without any validations for time being 
	@PostMapping("/initalStock")
	public ResponseEntity<String> uploadInitalStock(@RequestBody List<StockMaster> stockMasterList,@RequestParam("userid") String userid) throws Exception {
    	Map<String, Object> map = new HashMap<String, Object>();
    	if(stockMasterList != null && stockMasterList.size()>0) {
    		stockMasterList.parallelStream().forEach(stockmaster ->{
    			stockmaster.setUpdatedDate(new Date());
    			stockmaster.setUpdatedId(userid);
    			stockMasterRepository.saveAndFlush(stockmaster);
    		});
    		map.putAll(JSONResponseUtil.errorOrSuccessResponse("SavedSuccessfully ",STATUS.Success, "Inserted In StockMaster"));
    	}
    	else {
    		map.putAll(JSONResponseUtil.errorOrSuccessResponse("No record Found ",STATUS.Failure, "Empty"));
    		
    	}
    	return ResponseEntity.accepted().header(HttpHeaders.CONTENT_TYPE, "application/json")
				.body(JSONResponseUtil.response(map));
		
	}
	
	
}
