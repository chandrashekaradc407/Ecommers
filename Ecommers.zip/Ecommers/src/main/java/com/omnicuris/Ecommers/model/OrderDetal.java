package com.omnicuris.Ecommers.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class OrderDetal {
	private Long sno;
	private String itemCode;
	private String orderId;
	private Date createdDate;
	private Date UpdatedDate;
	private String userid;
	private boolean status;
	private String remarks;
//	@Transient
//	@ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "orderId", nullable = false)
//	private OrderHeader orderHeader;
	
	private int quantity;
	@Id
	@GeneratedValue
	public Long getSno() {
		return sno;
	}
	public void setSno(Long sno) {
		this.sno = sno;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getUpdatedDate() {
		return UpdatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		UpdatedDate = updatedDate;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "OrderDetal [sno=" + sno + ", itemCode=" + itemCode + ", orderId=" + orderId + ", createdDate="
				+ createdDate + ", UpdatedDate=" + UpdatedDate + ", userid=" + userid + ", status=" + status
				+ ", remarks=" + remarks + ", quantity=" + quantity + "]";
	}
	
	
}
