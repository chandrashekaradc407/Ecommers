package com.omnicuris.Ecommers.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.omnicuris.Ecommers.model.OrderDetal;

public interface OrderDetailRepository  extends JpaRepository<OrderDetal, Long>{

}
