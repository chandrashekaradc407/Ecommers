package com.omnicuris.Ecommers.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.omnicuris.Ecommers.model.OrderHeader;

public interface OrderHeaderRepository extends JpaRepository<OrderHeader, Long>{

	@Query("select  o from OrderHeader o where orderId=?1")
	OrderHeader findRegisterByOrderId(String orderId);

	
	@Query("select  o from OrderHeader o where userId=?1")
	List<OrderHeader> getAllOrderyByUserId(String userId);

}
